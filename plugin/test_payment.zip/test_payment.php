<?php
/**
 * Plugin Name: Test Payment Gateway
 */

if (!defined('ABSPATH')) exit;

add_action('plugins_loaded', 'init_test_payment_gateway');

function init_test_payment_gateway()
{
    if (!class_exists('WC_Payment_Gateway')) return;

    class WC_Test_Payment_Gateway extends WC_Payment_Gateway
    {

        public function __construct()
        {
            $this->id = 'test_gateway';
            $this->has_fields = false;
            $this->method_title = 'Test gateway';
            $this->method_description = 'Test payment gateway ';

            $this->init_form_fields();
            $this->init_settings();

            $this->title = $this->get_option('title');
            $this->description = $this->get_option('description');
            $this->enabled = $this->get_option('enabled');

            add_action('woocommerce_update_options_payment_gateways_' . $this->id, array($this, 'process_admin_options'));
        }

        public function init_form_fields()
        {
            $this->form_fields = array(
                'enabled' => array(
                    'title' => 'Enable/Disable',
                    'type' => 'checkbox',
                    'label' => 'Enable a custom payment method',
                    'default' => 'no'
                ),
                'title' => array(
                    'title' => 'Checkout title',
                    'type' => 'text',
                    'description' => 'This title will be seen by the client when placing an order.',
                    'default' => 'Test payment method',
                    'desc_tip' => true,
                ),
                'description' => array(
                    'title' => 'Checkout description',
                    'type' => 'textarea',
                    'description' => 'Instructions for the client at checkout.',
                    'default' => 'Payment by test',
                )
            );
        }

        public function process_payment($order_id)
        {
            $order = wc_get_order($order_id);
//            if isset payment gateway processing is here
            $order->update_status('processing', 'Payment success');

            WC()->cart->empty_cart();

            return array(
                'result' => 'success',
                'redirect' => $this->get_return_url($order)
            );
        }
    }
}

add_filter('woocommerce_payment_gateways', 'add_custom_gateway_class');
function add_custom_gateway_class($gateways)
{
    $gateways[] = 'WC_Test_Payment_Gateway';
    return $gateways;
}